<?php

$conn=mysqli_connect('localhost','id13450155_root','Root-12345678910','id13450155_hashmi');
$name=$_POST['name'];
 $ins="INSERT INTO `maincategory` (`name`) VALUES ('$name')";
 	$res=mysqli_query($conn,$ins);
	
echo" <script>window.location.href = 'main.php'</script>";
	
?>